###########################################################################
## Analytical Script for ``Buddha is a god: An empirical assessment'' 
## by Benjamin Grant Purzycki and Edward C. Holland
## R Script prepared by Benjamin Grant Purzycki
###########################################################################

################
### Packages ###
################

library(AnthroTools)
library(car)
library(doBy)
library(psych)
library(plyr)
library(tidyr)
library(lme4)

# Set working directory

setwd("")

# Import and rename data sets all at once if you'd like

Tyva_RLI <- read.csv("Tyva.RLI.csv")
demo <- read.csv("BuddhaList_Demo.csv")
d <- read.csv("CERC Dataset (Wave 1) Version 5.0_Tyva.csv")
FL2 <- read.csv("Tyva_FL_Buddha.csv")

## Study 1

## Free-list data of gods

# Demographic and free-list data summary

Tyva_RLI <- read.csv("Tyva.RLI.csv")
demo <- read.csv("BuddhaList_Demo.csv")

table(demo$SEX) # 1 = male
descStat(demo$AGE)
descStat(demo$FORMALED)

PRES <- FreeListTable(Tyva_RLI, CODE = "GODSPIRIT", Order = "ORDERG", Subj = "ID", tableType = "PRESENCE")
PRES <- PRES[,-1] # Delete the extra added column
PRES$Sum <- rowSums(PRES)
sum(PRES$Sum)
descStat(PRES$Sum)

# Assess free-list of gods

labs <- c("ID", "GODSPIRIT", "ORDERG")
RLI <- Tyva_RLI[labs]
RLI <- RLI[complete.cases(RLI),]
RLI <- data.frame(RLI)
RLI.S <- CalculateSalience(RLI, Order = "ORDERG", Subj = "ID", CODE = "GODSPIRIT", Salience = "Salience")
GOD.S <- SalienceByCode(RLI.S, Subj = "ID", CODE = "GODSPIRIT", Salience = "Salience",
                        dealWithDoubles="MAX")
GOD.S <- GOD.S[order(-GOD.S$SmithsS),] 
samplesize <- GOD.S[1,3]/GOD.S[1,4] # sample size
GOD.S$Nlist <- GOD.S$SumSalience/GOD.S$MeanSalience # number items listed
GOD.S$Psam <- GOD.S$Nlist/samplesize # percent of sample listing items
GOD.S$Pitem <- GOD.S$Nlist/sum(GOD.S$Nlist)
View(GOD.S)
#write.csv(GOD.S, "GOD.table.csv")

rank <- describeBy(Tyva_RLI$RANKG, Tyva_RLI$GODSPIRIT) # basic stats for ranking values by deity
rank$Buddha
rank$Jesus
rank$`place/territory eezi`
rank$`water eezi`
rank$Shakyamuni
rank$`Nogaan Darigi (Green Tara)`

propfunc <- function(v, f){ # this function creates a table of answers and proportions of "yes" answers
  table <- table(f, v)
  df <- as.data.frame.matrix(table)
  df$sum <- df$"0"+df$"1"+df$"D/K"
  df$prop.yes <- df$"1"/df$sum
  return(data.frame(df))
}

propfunc(Tyva_RLI$CONCERN, Tyva_RLI$GODSPIRIT)
propfunc(Tyva_RLI$SEE, Tyva_RLI$GODSPIRIT)
propfunc(Tyva_RLI$PUNISH, Tyva_RLI$GODSPIRIT)
propfunc(Tyva_RLI$REWARD, Tyva_RLI$GODSPIRIT)

## Study 2
## Experimental data set

d <- read.csv("CERC Dataset (Wave 1) Version 5.0_Tyva.csv")

# Basic summary stats of sample

samsize <- length(d$CERCID) # number of folks in study
table(d$SEX) # 0 = female; 1 = male
descStat(d$AGE)
descStat(d$FORMALED)
descStat(d$NATLANG)

# Discrete items

propfunc2 <- function(v){ # this function creates a table of answers and proportions of "yes" and "no" answers
  df <- as.data.frame.matrix(count(v))
  df <- df[-3,]
  sum <- sum(df$freq)
  df$prop <- df$freq/sum
  return(list("table" = data.frame(df), "sum" = sum))
}

propfunc2(d$BGPUNISH)
propfunc2(d$BGDIE)
propfunc2(d$BGFEEL)
propfunc2(d$BGSEE)

propfunc3 <- function(v){
  narm <- v[!is.na(v)]
  length <- length(narm)
  mean <- mean(narm)
  sd <- sd(narm)
  big2 <- sum(narm >=2)
  prop2 <- big2/length
  df <- data.frame(length, mean, sd, big2, prop2)
  colnames(df) <- c("n", "mean", "sd", "n>=2", "prop>=2")
  return(df)
  }

propfunc3(d$BGREWARD)
propfunc3(d$BGSTEAL)
propfunc3(d$BGLYING)
propfunc3(d$BGMURDER)
propfunc3(d$BGSTLIMP)
propfunc3(d$BGLIEIMP)
propfunc3(d$BGMURDIMP)

myvars <- c("BGSTEAL", "BGLYING", "BGMURDER", "BGSTLIMP", "BGLIEIMP", "BGMURDIMP")
morfac <- d[myvars]
alpha(morfac) # in case you get an error, try psych::alpha(morfac). ggplot2 interferes. Imperial scum.
alpha(morfac)$total$mean
alpha(morfac)$total$sd

morfacsub <- morfac[complete.cases(morfac),] # remove missings
ConsensusPipeline(morfacsub, numQ = 5, safetyOverride = FALSE, ComreyFactorCheck = FALSE) # consensus analysis
View(morfacsub) # see actual responses. Row number indicates participant on consensus analysis

binvars <- c("BGPUNISH", "BGDIE", "BGSEE", "BGFEEL")
binfac <- d[binvars]
alpha(binfac) # again, try, psych::alpha(binfac)

d$moralmean <- (d$BGSTEAL + d$BGLYING + d$BGMURDER + d$BGSTLIMP + d$BGLIEIMP + d$BGMURDIMP)/6
d$AGE.C <- d$AGE - mean(d$AGE)
d$FORMALED.C <- d$FORMALED -  mean(d$FORMALED)  

# Regressions

stacked <- gather(d, Quest, Resp, BGPUNISH, BGDIE, BGSEE, BGFEEL, factor_key = T) # stacks data set
stacked$X <- NULL # removes junk vector
#write.csv(stacked, "stackedset.csv")

regreport <- function(m){
  se <- sqrt(diag(vcov(m)))
  tabfull <- cbind(OR = fixef(m), LL = fixef(m) - 1.96 * se, UL = fixef(m) + 1.96 * se)
  return(exp(tabfull))
}

mfull <- glmer(Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + (1 | CERCID) + (1 | Quest),
               family = "binomial", data = stacked, na.action = na.omit)

m1 <- glmer(Resp ~ FORMALED.C + AGE.C + as.factor(MAT1) + as.factor(SEX) + (1 | CERCID) + (1 | Quest),
               family = "binomial", data = stacked, na.action = na.omit)

m2 <- glmer(Resp ~ FORMALED.C + AGE.C + as.factor(SEX) + (1 | CERCID) + (1 | Quest), 
            family = "binomial", data = stacked, na.action = na.omit)

m3 <- glmer(Resp ~ FORMALED.C + as.factor(SEX) + (1 | CERCID) + (1 | Quest), 
            family = "binomial", data = stacked, na.action = na.omit)

m4 <- glmer(Resp ~ 1 + FORMALED.C + (1 | CERCID) + (1 | Quest), 
            family = "binomial", data = stacked, na.action = na.omit)

m0 <- glmer(Resp ~ 1 + (1 | CERCID) + (1 | Quest),
            family = "binomial", data = stacked, na.action = na.omit)

regreport(mfull)
regreport(m1)
regreport(m2)
regreport(m3)
regreport(m4)
regreport(m0)

cbind(summary(mfull)$AIC, summary(m1)$AIC, summary(m2)$AIC, summary(m3)$AIC, summary(m4)$AIC, summary(m0)$AIC)

logistic(2.05782 - 0.28239148)

## Model including emotional proximity to Russians

plusruss <- glmer(Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + as.factor(MAT1) + OUTGREMO+ (1 | CERCID) + (1 | Quest),
                family = "binomial", data = stacked, na.action = na.omit)
regreport(plusruss)

## Free-list of Buddha's concerns

FL2 <- read.csv("Tyva_FL_Buddha.csv")

FL2sub <- FL2[which(FL2$Order==1),]
FL2sub <- data.frame(FL2sub)
FL2sub$Subject <- NULL
FLT <- FreeListTable(FL2sub, CODE = "BGD", Subj = "CERCID", tableType = "PRESENCE")
FLT$Subject <- NULL

df <- data.frame(colSums(FLT))
df <- df[-1,,FALSE]
df$Item <- rownames(df)
df$Frequency <- df$colSums.FLT. 
df <- data.frame(cbind(df$Item, df$Frequency))
colnames(df) <- c("Item", "Frequency")
df$Frequency <- as.numeric(as.character(df$Frequency))

# Plot 
prop.table(table(FL2sub$BGD))
prop.table(table(FL2sub$BGL))

levels = c("Morality", "Virtue", "Misc.", 
           "Drug Use", "Religion", "Ecology",
           "Ritual", "D/K", "People", "Food")
ProportionD = c(0.48, 0.22, 0.10, 0.10, 0.04, 0.04, 0.01, 0.01, 0.00, 0.00) # From above
ProportionL = c(0.30, 0.18, 0.07, 0.03, 0.12, 0.04, 0.21, 0.00, 0.11, 0.03) # From above
ProportionS <- c(0.48, 0.30, .22, .18, .10, .07, .10, .03, .04, .12, .04, 
                 .04, .01, .21, .01, .00, .00, .11, .00, .03) # same data, just ordered according to graph
BuddasCon <- rbind("Buddha's Dislikes" = ProportionD, "Buddha's Likes" = ProportionL)

windowsFonts(times = windowsFont("Calibri")) 

par(family = "times", font = 2, font.lab = 2, font.axis = 2, par(mar = c(9,4,4,2) + 0.5))
fig1 <- barplot(BuddasCon, beside = T, horiz=F, ylim = c(0,.6), names.arg = levels, cex.axis = 1.5, cex.lab = 1.8, cex.names = 2, las=2, legend = T,
        xlab = NULL, ylab = "Proportion of Sample Listing Item Type", args.legend = 
          list(x="topright", inset = 0.20, text.font = 1.5, cex = 1.8, pt.cex = 1, title = "Free-List Domain"))
arrows(fig1, ProportionS-.05, fig1, ProportionS+.05, length = .05, angle=90, code=3)
box()

#### Bayesian Models ####

setwd("")
stacked <- read.csv("stackedset.csv")

library(brms)

set.seed(7)

priors <- c(set_prior("normal(0,1)", class = "b"),
            set_prior("cauchy(0,2)", class = "sd"))

bfull.q <- brm(formula = Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + (1 | Quest), 
              data = stacked, family = binomial(link = logit),
              prior = priors,
              warmup = 1000, iter = 2000, chains = 4, control = list(adapt_delta = .99))
stanplot(bfull.q)
exp(fixef(bfull.q))

bfull.id <- brm(formula = Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + (1 | CERCID), 
               data = stacked, family = binomial(link = logit),
               prior = priors,
               warmup = 1000, iter = 2000, chains = 4, control = list(adapt_delta = .99))
stanplot(bfull.id)
exp(fixef(bfull.id))

# Frequentist equivalent

library(lme4)

mfull.q <- glmer(Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + (1 | Quest),
               family = "binomial", data = stacked, na.action = na.omit)

mfull.id <- glmer(Resp ~ FORMALED.C + AGE.C + CHILDREN + as.factor(MAT1) + as.factor(SEX) + (1 | CERCID),
               family = "binomial", data = stacked, na.action = na.omit)
